/*
 * ssdp_server.h
 *
 *  Created on: Jan 3, 2018
 *      Author: Administrator
 */

#ifndef SOURCE_NETWORK_SOCKET_SERVER_SSDP_SERVER_H_
#define SOURCE_NETWORK_SOCKET_SERVER_SSDP_SERVER_H_

void* SSDP_Init(void *pArg);


#endif /* SOURCE_NETWORK_SOCKET_SERVER_SSDP_SERVER_H_ */
