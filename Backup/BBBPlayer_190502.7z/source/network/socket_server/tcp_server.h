/*
 * tcp_server.h
 *
 *  Created on: Jan 10, 2018
 *      Author: Administrator
 */

#ifndef SOURCE_NETWORK_SOCKET_SERVER_TCP_SERVER_H_
#define SOURCE_NETWORK_SOCKET_SERVER_TCP_SERVER_H_

void *TCP_ServerMain(void *pArg);



#endif /* SOURCE_NETWORK_SOCKET_SERVER_TCP_SERVER_H_ */
