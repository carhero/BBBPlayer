/*
 * Init.cpp
 *
 *  Created on: Nov 30, 2017
 *      Author: Administrator
 */

int Init_CreateThreads(void);


